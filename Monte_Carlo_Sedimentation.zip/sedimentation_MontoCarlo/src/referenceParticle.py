'''
Created on 2018 M05 7

@author: Sheldon Van Middelkoop
'''


from math import sqrt
import random


class referenceParticle:
    '''
    classdocs
    '''

    def __init__(self, mass, velocityX, velocityY, velocityZ):
        '''
        Constructor, this creates all necessary
        '''

        self.mass = mass
        self.velocityX = velocityX
        self.velocityY = velocityY
        self.velocityZ = velocityZ

        return

    def __str__(self):
        '''
        String constructor for particle simulation.
        '''
        string = """Mass: {}, Velocity (x): {}, Velocity (y): {}, Velocity (z): {}""".format(
            self.mass, self.velocityX, self.velocityY, self.velocityZ)

        return string

    def relativeVelocity(self, particleVelocity):
        '''
        Compute the relative velocity of two interacting particles.
        '''

        relvelx = self.velocityX - particleVelocity[0]
        relvely = self.velocityY - particleVelocity[1]
        relvelz = self.velocityZ - particleVelocity[2]
        relativeVelocity = [relvelx, relvely, relvelz]

        return relativeVelocity

    def sigmaCompute(self, relVelocity):
        # print('{}'.format(
            # sqrt(relVelocity[0]**2 + relVelocity[1]**2 + relVelocity[2]**2)))
        relativevelocityMagnitude = sqrt(
            (relVelocity[0])**2 + (relVelocity[1]**2) + (relVelocity[2])**2)
        particleVelMag = sqrt((self.velocityX**2) +
                              (self.velocityY)**2 + (self.velocityZ)**2)
        'print(relativevelocityMagnitude)'
        'print(particleVelMag)'
        sigma = ((relativevelocityMagnitude) /
                 (relativevelocityMagnitude + particleVelMag)) * particleVelMag
        return sigma

    def collide_status(self, sigma):
        MU = 0.0
        randvel = random.gauss(MU, sigma)
        collide = False
        if randvel > 2 * sigma or randvel < -2 * sigma:
            collide = True
        return collide

    def updateVelocityAfterCollision(self, particleVelocity):
        '''
        Compute the relative velocity of two interacting particles.
        '''

        self.velocityX = self.velocityX + particleVelocity[0]
        self.velocityY = self.velocityY + particleVelocity[1]
        self.velocityZ = self.velocityZ + particleVelocity[2]

        return

    def updateMassAfterCollision(self, Mass):

        self.mass = self.mass + Mass

        return

    def velocityinUniformField(self, acceleration, density, Cd, Area):

        return sqrt((2 * self.mass * acceleration) / density * Cd * Area)

    def toString(self):

        string = """Mass: {}, Velocity (x): {}, Velocity (y): {}, Velocity (z): {}""".format(
            self.mass, self.velocityX, self.velocityY, self.velocityZ)

        return string
