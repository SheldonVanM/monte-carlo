"""
-------------------------------------------------------
[description of functions]
-------------------------------------------------------
Author:  your name
ID:      your ID
Email:   your Laurier email address
__updated__ = "2018-05-21"
-------------------------------------------------------
"""
from math import sqrt
import random


MU = 0.0


def velocityParticle(sigma):
    """
    -------------------------------------------------------
    Function which is called to give 
    -------------------------------------------------------
    Parameters:
        None - 
        Returns:
       velocity - a vector describing the velocity of the particle
       in question done by a simple array filled will random numbers. 
    -------------------------------------------------------
    """

    return [random.gauss(MU, sigma), random.gauss(MU, sigma), random.gauss(MU, sigma)]


def v_due2acceleration(mass, acceleration, density, CD, Area):
    """
    -------------------------------------------------------
    Calculates the velocity in stokes regime in a liquid 
    suspension
    -------------------------------------------------------
    Parameters:
        mass - the masss of the particle in suspension
        acceleration - The acceleration either due to gravity or centrifugation
        density - the density of the fluid e.g. water = 997 kg/m^3
        CD - the shape factor of the particle
        Area - the cross sectional area of the particle 
        Returns:
       velocity - a scalar describing the velocity of the particle
    -------------------------------------------------------
    """

    return sqrt((2 * mass * acceleration / (density * CD * Area)))


def timeFormat2String(time):
    """
    -------------------------------------------------------
    Computes formatting for the time from seconds to days, hours,
    minutes, seconds.
    -------------------------------------------------------
    Parameters:
        time - the time it takes for the particle to sediment in seconds
        Returns:
        - the time reformatted in seconds as an array
    -------------------------------------------------------
    """

    seconds = time % 60
    minutes = time // 60
    hours = 0
    days = 0
    years = 0
    if(minutes > 59):
        hours = minutes // 60
        minutes = minutes % hours
    if(hours > 23):
        days = hours // 24
        hours = minutes // 60
        if hours != 0:
            minutes = minutes % hours
    if(days > 364):
        years = days // 365
        days = hours // 24
        hours = minutes // 60
        if hours != 0:
            minutes = minutes % hours

    return [seconds, minutes, hours, days, years]
