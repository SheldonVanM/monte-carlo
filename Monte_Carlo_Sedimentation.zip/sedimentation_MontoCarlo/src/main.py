"""
-------------------------------------------------------
The main function for a molecular dynamics simulation using Monte Carlo techniques to measure and describe 
sedimentation and centrifugation of 2D materials post exfoliation.
-------------------------------------------------------
Author:  Sheldon Van Middelkoop
Version: 1.0
Email:    svanmidd@uwo.ca
__updated__ = "2018-05-20"
-------------------------------------------------------
"""

from _overlapped import NULL
import math
import random

from particleVelocity import velocityParticle
from referenceParticle import referenceParticle
import particleVelocity


MASS = 2 * 10**-24
MU = 0
SIGMA = 0.1
CD = 0.3
AREA = 10**-14
time = 0
acceleration = 9.804
cont = True
sedType = NULL

while(cont):
    sedType = str(input('Is this sedimentation of centrifugation (S/C): '))
    if(sedType == 'C' or sedType == 'c'):
        rpm = float(input('Enter the rpm speed: '))
        diameter = float(input('Enter diameter of centrifuge drum (m): '))
        radPerSec = (rpm / 60) / (2 * math.pi)
        acceleration = (diameter / 2) * (radPerSec**2)
        height = float(input('Enter height the particle is at (m): '))
        deltaT = float(
            input('Enter the average relaxation of the particles (s): '))
        density = 997
        reference = referenceParticle(MASS, random.gauss(
            MU, SIGMA), random.gauss(MU, SIGMA), random.gauss(MU, SIGMA))
        new_particle = velocityParticle(SIGMA)
        sigma = reference.sigmaCompute(new_particle)

        while height >= 0:
            if reference.collide_status(sigma):
                reference.updateMassAfterCollision(MASS)
            reference.updateVelocityAfterCollision

            height = height - deltaT * \
                (particleVelocity.v_due2acceleration(
                    reference.mass, acceleration, density, CD, AREA))
            time += deltaT
        print("")
        print("The final mass of the sedimented particle is {:.35f} kg".format(
            reference.mass))
        format_times = particleVelocity.timeFormat2String(time)
        print('Time:   Years: {0}  days: {1}   Hours: {2}   Minutes: {3}  Seconds: {4}  '.format(
            int(format_times[4]), int(format_times[3]), int(format_times[2]), int(format_times[1]), int(math.floor(format_times[0]))))

        cont = False

    elif(sedType == 'S' or sedType == 's'):
        height = float(input('Enter height the particle is at (m): '))
        deltaT = float(
            input('Enter the average relaxation of the particles (s): '))
        density = 997
        reference = referenceParticle(MASS, random.gauss(
            MU, SIGMA), random.gauss(MU, SIGMA), random.gauss(MU, SIGMA))
        new_particle = velocityParticle(SIGMA)
        sigma = reference.sigmaCompute(new_particle)

        while height >= 0:
            if reference.collide_status(sigma):
                reference.updateMassAfterCollision(MASS)
            reference.updateVelocityAfterCollision

            height = height - deltaT * \
                (particleVelocity.v_due2acceleration(
                    reference.mass, acceleration, density, CD, AREA))
            time += deltaT
        print("")
        print("The final mass of the sedimented particle is {:.35f} kg".format(
            reference.mass))
        format_times = particleVelocity.timeFormat2String(time)
        print('Time:   Years: {0}  days: {1}   Hours: {2}   Minutes: {3}  Seconds: {4}  '.format(
            int(format_times[4]), int(format_times[3]), int(format_times[2]), int(format_times[1]), int(math.floor(format_times[0]))))
        cont = False
    else:
        print(
            'Error: Incorrect input for sedminetation type. Please use the letter S or C.')
